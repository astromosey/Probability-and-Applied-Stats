import java.util.*;
import java.lang.Math;
import java.math.BigInteger;

public class StatsLibrary {
		
	
	//Mean
	public double mean(ArrayList<Integer> list) {
		double sum = 0;
		double avg = 0;
		for (int i = 0; i < list.size(); i++) {
			sum += list.get(i);
		}
		
		avg = sum / list.size();
		return avg;
	}
	
	//Median
	public double median(ArrayList<Integer> list) {
		Collections.sort(list);
		double median;
		
		if (list.size() % 2 == 1) {
			int odd = (list.size() - 1)/ 2;
			median = list.get(odd);
		}
		else {
			int even = list.size() / 2;
			median = (double) (list.get(even) + list.get(even - 1)) / 2;
		}
		
		return median;
	}
	
	//Mode
	public Integer mode(ArrayList<Integer> list) {
		// Returns null if there is no mode or if there is more than one mode
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		int temp = 0;
		int greatest = 0;
		int index = 0;
		Integer mode;
		
		for (int i = 0; i < list.size(); i++) {
			int count = 0;
			for (int j = 0; j < list.size(); j++) {
				if (list.get(i) == list.get(j))
					count++;
			}
			map.put(list.get(i), count);
		}
		
		for (int i = 0; i < list.size(); i++) {
			temp = map.get(list.get(i));
			if (temp > greatest) {
				greatest = temp;
				index = i;
			}
		}
		
		map.remove(list.get(index));
		
		if (map.containsValue(greatest) || greatest <= 1)
			mode = null;
		else
			mode = list.get(index);
		
		return mode;
	}
	//Standard Deviation
	public double standardDeviation(ArrayList<Integer> list) {
		double sum = 0;
		double standardDeviation = 0;
		double avg = mean(list);
		
		for (int i = 0; i < list.size(); i++) {
			sum += Math.pow((list.get(i) - avg), 2);
		}
		standardDeviation = Math.sqrt((sum/list.size()));
		return standardDeviation;
	}
	//Complement
	public ArrayList<Integer> complement(ArrayList<Integer> list1, ArrayList<Integer> list2) {
		for (int i = 0; i < list1.size(); i++) {
			if (list2.contains(list1.get(i))) 
				list2.remove(list1.get(i));
		}
		return list2;
	}
	//Intersection
	public ArrayList<Integer> intersection(ArrayList<Integer> list1, ArrayList<Integer> list2) {
		ArrayList<Integer> intersection = new ArrayList<Integer>();
		
		for (int i = 0; i < list1.size(); i++) {
			if (list2.contains(list1.get(i)))
				intersection.add(list1.get(i));
		}
		
		return intersection;
	}
	//Union
	public ArrayList<Integer> union(ArrayList<Integer> list1, ArrayList<Integer> list2) {
		for (int i = 0; i < list1.size(); i++) {
			if (!list2.contains(list1.get(i)))
				list2.add(list1.get(i));
		}
		
		return list2;
	}
	//Factorial
	public BigInteger factorial(int x) {
		BigInteger result = BigInteger.valueOf(x);
		
		for (int i = 1; i < x; i++)
			result = result.multiply(BigInteger.valueOf(i));
		
		return result;
	}
	//Combination
	public BigInteger combination(int n, int r) {
		BigInteger result;
		
		result = (factorial(n)).divide((factorial(r).multiply(factorial(n - r))));
		
		return result;
	}
	//Permutation
	public BigInteger permutation(int n, int r) {
		BigInteger result;
		
		result = factorial(n).divide(factorial(n - r));
		
		return result;
	}
	//Binomial Distribution
	public double binomialDistribution(int n, int y, double p) {
		double probability;
		//q is the probability of failure for a single trial
		double q = 1 - p;
		double comb = combination(n, y).doubleValue();

		probability = comb * (Math.pow(p,  y)) * (Math.pow(q,  (n - y)));
		
		return probability;
	}
	//Geometric Distribution
	public double geometricDistribution(int n, double p) {
		double probability;
		//q is the probability of failure for a single trial
		double q = 1 - p;
		
		probability = (Math.pow(q, n-1)) * p;
		
		return probability;
	}
	//Hypergeometric Distribution
	public double hypergeometricDistribution(int n, int m, int r, int y) {
		double probability;
		
		probability = (combination(r, y).multiply(combination(n - r, m - y))).doubleValue() / (combination(n, m).doubleValue());
		
		return probability;
	}
	//Poisson Distribution
	public double poissonDistribution(int lambda, int y) {
		double probability;
		
		double negativeLambda = lambda * -1;
		probability = (Math.pow(lambda, y) / factorial(y).doubleValue()) * (Math.exp(negativeLambda));
		
		return probability;
	}
	// Chebyshev’s theorem 
	public double chebyshev(double lowerRange, double upperRange, double mean, double standardDeviation) {
		double percentage;
		double k = (upperRange - mean) / standardDeviation;
		percentage = 1 - (1 / (k*k));
		
		return percentage;
	}
}
