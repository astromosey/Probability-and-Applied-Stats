import java.util.*;
import java.util.Scanner;
import java.util.Collections;
public class StatsLibraryTester {
	public static void main(String[] args) {
		StatsLibrary lib = new StatsLibrary();
		Scanner scan = new Scanner(System.in);
		
		ArrayList<Integer> SetA = new ArrayList<Integer>();
		ArrayList<Integer> SetB = new ArrayList<Integer>();
		ArrayList<Integer> UniversalSet = new ArrayList<Integer>();
		
		SetA.add(1);
		SetA.add(3);
		SetA.add(5);
		SetA.add(6);
		SetA.add(8);
		SetA.add(8);
		
		SetB.add(1);
		SetB.add(2);
		SetB.add(4);
		SetB.add(6);
		SetB.add(7);

		for (int i = 1; i <= 10; i++) {
			UniversalSet.add(i);
		}
		
		System.out.println("Mean (Set A) = " + lib.mean(SetA));
		System.out.println("Mean (Set B) = " + lib.mean(SetB));
		System.out.println("Median (Set A) = " + lib.median(SetA));
		System.out.println("Median (Set B) = " + lib.median(SetB));
		System.out.println("Mode (Set A) = " + lib.mode(SetA));
		System.out.println("Mode (Set B) = " + lib.mode(SetB));
		System.out.println("Standard Deviation (Set A) = " + lib.standardDeviation(SetA));
		System.out.println("Complement (Set A, Universal Set) = " + lib.complement(SetA, UniversalSet));
		System.out.println("Intersection of Sets = " + lib.intersection(SetA, SetB));
		System.out.println("Union of Sets = " + lib.union(SetA, SetB));
		System.out.println("5! = " + lib.factorial(5));
		System.out.println("Permutation (13, 4) = " + lib.permutation(13, 4));
		System.out.println("Combination (13, 4) = " + lib.combination(13, 4));
		System.out.println("Binomial Distribution (p=0.90, q=0.20, n=8, y=5): " + lib.binomialDistribution(8, 5, 0.90));
		System.out.println("Geometric Distribution (p=0.06, q=0.96, n=3): " + lib.geometricDistribution(3, 0.06));
		
	}
}
