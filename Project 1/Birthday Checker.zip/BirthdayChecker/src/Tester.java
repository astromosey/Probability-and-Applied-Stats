import java.util.Scanner;
public class Tester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter class size: ");
        int classSize = scanner.nextInt();

        System.out.print("Enter number of runs: ");
        int numberOfRuns = scanner.nextInt();

        int numberOfSharedBirthday = 0;

        for (int i = 0; i < numberOfRuns; i++) {
            if (runSimulation(classSize)) {
                numberOfSharedBirthday++;
            }
        }

        double probability = (double) numberOfSharedBirthday / numberOfRuns;
        System.out.println("Probability of at least two people sharing a birthday in a class of " + classSize + " is: " + probability);

        scanner.close();
    }

	private static boolean runSimulation(int classSize) {
		// TODO Auto-generated method stub
		return false;
	}
}
