import java.util.ArrayList;
import java.util.Random;

public class BirthdayProbability {
    public static boolean runSimulation(int classSize) {
        ArrayList<Person> people = new ArrayList<>();
        Random random = new Random();

        // Generate random birthdays for the class
        for (int i = 0; i < classSize; i++) {
            int birthday = random.nextInt(365); // Ignoring leap years
            people.add(new Person(birthday));
        }

        // Check if there are any shared birthdays
        for (int i = 0; i < classSize; i++) {
            for (int j = i + 1; j < classSize; j++) {
                if (people.get(i).birthday == people.get(j).birthday) {
                    return true; // Shared birthday found
                }
            }
        }

        return false; // No shared birthdays
    }

}
