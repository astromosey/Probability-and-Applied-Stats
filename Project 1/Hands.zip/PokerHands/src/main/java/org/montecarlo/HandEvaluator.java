package org.montecarlo;

import com.opencsv.CSVWriter;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HandEvaluator {
    private final ArrayList<Card> deck;

    private ArrayList<Card> localDeck;
    private final ArrayList<Card> hand;

    double pairCount = 0;
    double threeOfAKindCount = 0;
    double fourOfAKindCount = 0;
    double straightCount = 0;
    double flushCount = 0;
    double fullHouseCount = 0;
    double straightFlushCount = 0;
    double royalFlushCount = 0;
    double highCardCount = 0;

    public HandEvaluator() {
        deck = new ArrayList<>();
        hand = new ArrayList<>();
        populateDeck();
        localDeck = (ArrayList<Card>) deck.clone();
        shuffleDeck();
    }

    private void populateDeck() {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Card(suit, value));
            }
        }
    }

    private void shuffleDeck() {
        Collections.shuffle(localDeck);
    }

    private void resetDeck() {
        localDeck = (ArrayList<Card>) deck.clone();
    }

    public Card drawCard() {
        if (localDeck.isEmpty()) {
            System.out.println("No more cards in the deck.");
            return null;
        }
        return localDeck.remove(0);
    }

    public void drawHand(int handSize) {
        hand.clear();
        for (int i = 0; i < handSize; i++) {
            hand.add(drawCard());
        }
    }

    public void printHand() {
        for (Card card : hand) {
            System.out.println(card.getValue() + " of " + card.getSuite());
        }
    }

    // Method to deal a specified number of hands
    public void dealHands(int numHands, int handSize) {
        for (int i = 0; i < numHands; i++) {
            drawHand(handSize);

            String debug = System.getProperty("debug");
            if (debug != null && debug.equals("true")) {
                System.out.println("Hand " + (i + 1) + ":");
                printHand();
                System.out.println("---------------------");
            }

            evaluateHand(hand);
            resetDeck();
            shuffleDeck(); // Reset the deck
        }
        printProbability(numHands, handSize);
        writeProbabilityResultsToCsv(numHands, handSize, "result.csv");
        resetCounts();
    }

    private void resetCounts() {
        pairCount = 0;
        threeOfAKindCount = 0;
        fourOfAKindCount = 0;
        straightCount = 0;
        flushCount = 0;
        fullHouseCount = 0;
        straightFlushCount = 0;
        royalFlushCount = 0;
        highCardCount = 0;
    }

    // Method to check if the hand contains a pair
    public boolean hasPair(ArrayList<Card> hand) {
        HashMap<String, Integer> valueCounts = new HashMap<>();

        // Count the occurrences of each card value in the hand
        for (Card card : hand) {
            String value = card.getValue();
            valueCounts.put(value, valueCounts.getOrDefault(value, 0) + 1);
        }

        // Check for pairs
        for (int count : valueCounts.values()) {
            if (count == 2) {
                return true; // Found a pair
            }
        }
        return false; // No pair found
    }


    // Method to check if the hand has three of a kind
    public boolean hasThreeOfAKind(ArrayList<Card> hand) {
        HashMap<String, Integer> valueCounts = new HashMap<>();

        // Count the occurrences of each card value in the hand
        for (Card card : hand) {
            String value = card.getValue();
            valueCounts.put(value, valueCounts.getOrDefault(value, 0) + 1);
        }

        // Check for pairs
        for (int count : valueCounts.values()) {
            if (count == 3) {
                return true; // Found a pair
            }
        }
        return false; // No pair found
    }

    // Method to check if the hand has four of a kind
    public boolean hasFourOfAKind(ArrayList<Card> hand) {
        HashMap<String, Integer> valueCounts = new HashMap<>();

        // Count the occurrences of each card value in the hand
        for (Card card : hand) {
            String value = card.getValue();
            valueCounts.put(value, valueCounts.getOrDefault(value, 0) + 1);
        }

        // Check for pairs
        for (int count : valueCounts.values()) {
            if (count == 4) {
                return true; // Found a pair
            }
        }
        return false; // No pair found
    }

    // Method to check if the hand has a straight
    public boolean hasStraight(ArrayList<Card> hand) {
        Set<String> uniqueValues = new HashSet<>();

        // Check for duplicates and store unique values
        for (Card card : hand) {
            if (!uniqueValues.add(card.getValue())) {
                return false; // Duplicate value found, not a straight
            }
        }

        // Sort the values to check for a sequence
        ArrayList<String> sortedValues = new ArrayList<>(uniqueValues);
        Collections.sort(sortedValues);

        // Check for a sequence of consecutive values
        int consecutiveCount = 0;
        for (int i = 0; i < sortedValues.size() - 1; i++) {
            if (getValueRank(sortedValues.get(i + 1)) - getValueRank(sortedValues.get(i)) == 1) {
                consecutiveCount++;
            } else {
                consecutiveCount = 0; // Reset if not consecutive
            }

            if (consecutiveCount == 4) {
                return true; // Found a straight
            }
        }

        return false; // No straight found
    }

    // Helper method to get the rank of a card value
    private int getValueRank(String value) {
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(value)) {
                return i;
            }
        }
        return -1; // Invalid value
    }

    // Method to check if the hand has a flush
    public boolean hasFlush(ArrayList<Card> hand) {
        String firstSuite = hand.get(0).getSuite();

        // Check if all cards have the same suit
        for (Card card : hand) {
            if (!card.getSuite().equals(firstSuite)) {
                return false; // Different suit found, not a flush
            }
        }

        return true; // All cards have the same suit, it's a flush
    }

    // Method to check if the hand has a full house
    public boolean hasFullHouse(ArrayList<Card> hand) {
        HashMap<String, Integer> valueCounts = new HashMap<>();

        // Count the occurrences of each card value in the hand
        for (Card card : hand) {
            String value = card.getValue();
            valueCounts.put(value, valueCounts.getOrDefault(value, 0) + 1);
        }

        boolean hasPair = false;
        boolean hasThreeOfAKind = false;

        // Check for both a pair and three of a kind
        for (int count : valueCounts.values()) {
            if (count == 2) {
                hasPair = true;
            } else if (count == 3) {
                hasThreeOfAKind = true;
            }
        }

        return hasPair && hasThreeOfAKind;
    }

    // Method to check if the hand has a straight flush
    public boolean hasStraightFlush(ArrayList<Card> hand) {
        return hasStraight(hand) && hasFlush(hand);
    }

    // Method to check if the hand has a royal flush
    public boolean hasRoyalFlush(ArrayList<Card> hand) {
        // Check for a straight flush
        if (!hasStraightFlush(hand)) {
            return false;
        }

        // Check if the values are 10, J, Q, K, A
        ArrayList<String> royalValues = new ArrayList<>(List.of("10", "J", "Q", "K", "A"));

        Set<String> handValues = new HashSet<>();
        for (Card card : hand) {
            handValues.add(card.getValue());
        }

        return handValues.containsAll(royalValues);
    }


    // Method to check if the hand has high card
    public boolean hasHighCard(ArrayList<Card> hand) {
        return !hasPair(hand) && !hasThreeOfAKind(hand) && !hasFourOfAKind(hand) &&
                !hasStraight(hand) && !hasFlush(hand) && !hasFullHouse(hand) &&
                !hasStraightFlush(hand) && !hasRoyalFlush(hand);
    }

    // Method to evaluate and print the type of hand
    public void evaluateHand(ArrayList<Card> hand) {
        if (hasRoyalFlush(hand)) {
            royalFlushCount++;
        } else if (hasStraightFlush(hand)) {
            straightFlushCount++;
        } else if (hasFourOfAKind(hand)) {
            fourOfAKindCount++;
        } else if (hasFullHouse(hand)) {
            fullHouseCount++;
        } else if (hasFlush(hand)) {
            flushCount++;
        } else if (hasStraight(hand)) {
            straightCount++;
        } else if (hasThreeOfAKind(hand)) {
            threeOfAKindCount++;
        } else if (hasPair(hand)) {
            pairCount++;
        } else {
            highCardCount++;
        }
    }

    private void printProbability(int numHands, int handSize) {
        System.out.printf("**** Probability Results for hand of %d cards !!! ****\n", handSize);
        System.out.printf("Pair Count : %.3f\n", pairCount / numHands);
        System.out.printf("Three of a Kind : %.3f\n", threeOfAKindCount / numHands);
        System.out.printf("Four of a Kind : %.3f\n", fourOfAKindCount / numHands);
        System.out.printf("Straight : %.3f\n", straightCount / numHands);
        System.out.printf("Flush : %.3f\n", flushCount / numHands);
        System.out.printf("Full House : %.3f\n", fullHouseCount / numHands);
        System.out.printf("Straight Flush : %.3f\n", straightFlushCount / numHands);
        System.out.printf("Royal Flush : %.3f\n", royalFlushCount / numHands);
        System.out.printf("High Card : %.3f\n", highCardCount / numHands);
        System.out.printf("*********************************\n");
        System.out.printf("*********************************\n");
    }

    private void writeProbabilityResultsToCsv(int numHands, int handSize, String outputFile) {
        boolean fileIsEmpty = !new File(outputFile).exists();

        try (CSVWriter writer = new CSVWriter(new FileWriter(outputFile, true))) {
            // Append data to an existing file
            if (fileIsEmpty) {
                // Write header if the file is empty
                writer.writeNext(new String[]{"Hand Size", "Hand Type", "Probability"});
            }

            writer.writeNext(new String[]{String.format("%d", handSize), "Pair", String.format("%.3f", pairCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Three of a Kind", String.format("%.3f", threeOfAKindCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Four of a Kind", String.format("%.3f", fourOfAKindCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Straight", String.format("%.3f", straightCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Flush", String.format("%.3f", flushCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Full House", String.format("%.3f", fullHouseCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Straight Flush", String.format("%.3f", straightFlushCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "Royal Flush", String.format("%.3f", royalFlushCount / numHands)});
            writer.writeNext(new String[]{String.format("%d", handSize), "High Card", String.format("%.3f", highCardCount / numHands)});
            writer.writeNext(new String[]{"","",""});

            System.out.println("Probability results appended to " + outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
