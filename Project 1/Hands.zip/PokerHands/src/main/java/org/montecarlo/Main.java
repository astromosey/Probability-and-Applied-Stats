package org.montecarlo;

public class Main {
    public static void main(String[] args) {
        HandEvaluator handEvaluator = new HandEvaluator();
        handEvaluator.dealHands(10000, 3); // Deal 10,000 3-card hands
        handEvaluator.dealHands(10000, 5); // Deal 10,000 5-card hands
        handEvaluator.dealHands(10000, 7); // Deal 10,000 7-card hands
        handEvaluator.dealHands(10000, 9); // Deal 10,000 9-card hands
    }
}
