
import java.util.Random;

/**PROBLEM 2.20:
  
  a) If the contestant has no idea which curtains hide the various 
  prizes and selects a curtain at random, assign reasonable probabilities 
  to the simple events and calculate the probability that the 
  contestant selects the curtain hiding the nice prize.

 *  Answer: There are 3 doors and the contestant is unaware of
 *  which door holds the prize. Therefore, 
 *  P(G) = 1/3
 *  P(D1) = 1/3
 *  P(D2) = 1/3
 *  Sp, the probability that the contestant selects the curtain
 *  with the nice prize is 1/3.
   
   b) Before showing the contestant what was behind the curtain 
   initially chosen, the game show host would open one of the 
   curtains and show the contestant one of the duds (he could 
   always do this because he knew the curtain hiding the good prize).
   He then offered the contestant the option of changing from the 
   curtain initially selected to the other remaining unopened curtain. 
   Which strategy maximizes the contestant’s probability of winning the 
   good prize: stay with the initial choice or switch to the other curtain? 
   In answering the following sequence of questions, you will discover that, 
   perhaps surprisingly, this question can be answered by considering only 
   the sample space above and using the probabilities that you assigned to 
   answer part (a).
   
 * Answer: 
 * (i) 1/3
 * (ii) 0
 * (iii) 1
 * (iv) 2/3     
 * (v) Switching to the other curtain maximizes the contestant's probability of winning
 * the good prize, as the probability of winning after switching is 2/3, while it
 * is 1/3 if the contestant doesn't switch.
 
 **/
public class MontyHall {

    private static final int NUMBER_OF_TRIALS = 10000;
    private static final Random RANDOM_GENERATOR = new Random();

    public static void main(String[] args) {
        String[] options = new String[]{"G", "D1", "D2"}; // G represents win
        getPercentageWinIfDoorIsNotChanged(options);
        getPercentageWinIfDoorIsChangedEverytime(options);
    }

    /**
     * Method that computes and outputs the % scores when door is not changed
     *
     * @param options
     */
    private static void getPercentageWinIfDoorIsNotChanged(String[] options) {
        int winCount = 0;
        for (int i = 0; i < NUMBER_OF_TRIALS; i++) {
            int randomlySelectedIndex = RANDOM_GENERATOR.nextInt(3);
            String selectedValue = options[randomlySelectedIndex];
            boolean isWin = selectedValue.equals("G");
            if (isWin)
                winCount++;
        }
        double percentageWin = winCount / (double) NUMBER_OF_TRIALS;
        System.out.printf("Percentage of winning when door is not changed: %s%n", percentageWin);
    }

    /**
     * Method that computes and outputs the % scores when door is changed everytime
     *
     * @param options
     */
    private static void getPercentageWinIfDoorIsChangedEverytime(String[] options) {
        int winCount = 0;
        for (int i = 0; i < NUMBER_OF_TRIALS; i++) {
            int randomlySelectedIndex = RANDOM_GENERATOR.nextInt(3);
            String selectedValue = options[randomlySelectedIndex];
            boolean FirstSelectionWin = selectedValue.equals("G");
            // If first selection is a win, then it is sure the next selection will never be a win.
            if (!FirstSelectionWin && RANDOM_GENERATOR.nextInt(1) == 0) {
                winCount++;
            }
        }
        double percentageWin = winCount / (double) NUMBER_OF_TRIALS;
        System.out.printf("Percentage of winning when door is changed everytime: %s%n", percentageWin);
    }

}