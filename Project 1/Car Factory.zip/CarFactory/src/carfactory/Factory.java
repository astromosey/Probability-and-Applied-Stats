package carfactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Factory {
    // Method to create a new cars
    public static Car createCar() {
        String[] carTypes = {"Sedan", "SUV", "Truck", "Coupe"};
        String[] colors = {"Red", "Blue", "Black", "White", "Silver"};

        Random random = new Random();
        
        

        // Sedans slightly popular
        int res=random.nextInt(carTypes.length);
 
        String cartype = carTypes[res];
        

        // Year within the last 50 years (from 1973 to 2022)
        int year = 1973 + random.nextInt(50);

        // Red slightly more popular
        String color = (random.nextInt(100) < 55) ? "Red" : colors[random.nextInt(colors.length)];

        // Random miles between 0 and 250,000
        int miles = random.nextInt(250001);
        
       // System.out.println(cartype+","+year+","+color+","+miles);
        return new Car(cartype, year, color, miles);
    }

    // Method to generate and return a list of cars
    public static List<Car> generateCars(int numberOfCars) {
    	List<Car> cars = new ArrayList<Car>();
    	int row=0;
        for (int i = 0; i < numberOfCars; i++) { 	
        	
            String[] carTypes = {"Sedan", "SUV", "Truck", "Coupe"};
            String[] colors = {"Red", "Blue", "Black", "White", "Silver"};
            Random random = new Random();

            // Sedans more popular
            //String cartype = carTypes[i % carTypes.length];
            String cartype = carTypes[random.nextInt(carTypes.length)];

            // Year within the last 50 years (from 1973 to 2022)
            int year = 1973 + (i % 50);

            // Slightly favoring Red color
            String color = (i % 100 < 55) ? "Red" : colors[i % colors.length];

            // Random miles between 0 and 250,000
            int miles = (int) (Math.random() * 250001);
            System.out.println(cartype+","+year+","+color+","+miles);
            cars.add(row,new Car(cartype, year, color, miles));
            row++;
        }
        return cars;
    }

    // Main method to demonstrate usage
    public static void main(String[] args) {
        // Generate 10 cars for demonstration
        List<Car> cars = generateCars(10);

        // Display information of generated cars
        for (int i = 0; i < cars.size(); i++) {
            //System.out.println("Car " + (i + 1) + " Information:");
            //System.out.println(cars.get(i));
            cars.get(i).displayInfo();
            System.out.println();
        }
    }
}

