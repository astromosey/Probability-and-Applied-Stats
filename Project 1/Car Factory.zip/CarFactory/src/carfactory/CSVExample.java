package carfactory;

import java.io.*;

import java.util.List;
import java.util.Scanner;

public class CSVExample {
    public void writeCarsToCSV(List<Car> cars, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Writing CSV header
            writer.write("Car Type,Year,Color,Miles");
            writer.newLine();

            // Writing car data to CSV
            for (Car car : cars) {
                writer.write(car.getCartype() + "," + car.getYear() + "," + car.getColor() + "," + car.getMiles());
                writer.newLine();
            }

            System.out.println("Cars data has been written to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void readCarsFromCSV(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            // Skip header
            scanner.nextLine();

            // Read and display car data from CSV
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                String cartype = data[0];
                int year = Integer.parseInt(data[1]);
                String color = data[2];
                int miles = Integer.parseInt(data[3]);

                // Create Car objects and display information
                Car car = new Car(cartype, year, color, miles);
                car.displayInfo();
                System.out.println();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
    	
    	CSVExample CSVExample= new CSVExample();

        // Generate 1000 cars
        List<Car> cars = Factory.generateCars(1000);

        // Write cars to CSV file
        String filePath = "cars.csv";
        CSVExample.writeCarsToCSV(cars, filePath);


        // Read cars from CSV file and display them
        System.out.println("\nReading cars from CSV:");
        readCarsFromCSV(filePath);
    }
}
