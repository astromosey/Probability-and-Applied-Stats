package carfactory;

public class Car {
	    // Global variables
	    public  String cartype;
		public  int year;
	    public  String color;
	    public  int miles;

	    // Constructor
	    
	    public Car() {}
	    public Car(String cartype, int year, String color, int miles) {
			super();
			this.cartype = cartype;
			this.year = year;
			this.color = color;
			this.miles = miles;
		}
		public String getCartype() {
			return cartype;
		}
		public void setCartype(String cartype) {
			this.cartype = cartype;
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
		public int getMiles() {
			return miles;
		}
		public void setMiles(int miles) {
			this.miles = miles;
		}
	    
		public void displayInfo() {
	        System.out.println("Car Type: " + cartype);
	        System.out.println("Year: " + year);
	        System.out.println("Color: " + color);
	        System.out.println("Miles: " + miles);
	    }
}
	   