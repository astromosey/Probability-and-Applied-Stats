package carfactory;

import java.io.*;


import java.util.List;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;

public class Excel {

    public static void main(String[] args) {
    	
    	CSVExample CSVExample= new CSVExample();
    	Excel excel= new Excel();
    	
        // Generate 1000 cars
        List<Car> cars = Factory.generateCars(1000);

        // Write cars to CSV file
        String filePath = "cars.csv";
        CSVExample.writeCarsToCSV(cars, filePath);

        // Load data from CSV file
        //List<String[]> csvData = readCsvFile("cars.csv");

        // Create an Excel file with the loaded data
        String excelFilePath = "cars_data.xlsx";
        excel.createExcelFile(cars, excelFilePath);

        // Generate a bar chart from the Excel data
        DefaultCategoryDataset dataset = excel.loadDataFromExcel("cars_data.xlsx");
       
        JFreeChart barChart = ChartFactory.createBarChart("Car-Miles Chart", "Car Type", "Miles", dataset, PlotOrientation.VERTICAL,true,true,false  );
        //excel.displayChart(barChart, "Car Types Distribution");
        excel.saveChartAsImage(barChart, "CarTypeChart.png"); // Save chart as an image

             
        // Add the chart image to the Excel file
        excel.addChartImageToExcel(excelFilePath, "CarTypeChart.png");

        System.out.println("Data and chart saved in the Excel file successfully.");
    }

    private void addChartImageToExcel(String excelFilePath, String chartImagePath) {
    	try (FileInputStream fileInputStream = new FileInputStream(excelFilePath);
                Workbook workbook = new XSSFWorkbook(fileInputStream);
                FileOutputStream fileOutputStream = new FileOutputStream(excelFilePath)) {
               Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet

               // Create drawing patriarch
               Drawing<?> drawing = sheet.createDrawingPatriarch();
               ClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 10, 15, 25);

               // Load the chart image
               FileInputStream chartImage = new FileInputStream(chartImagePath);
               byte[] bytes = IOUtils.toByteArray(chartImage);
               int pictureIndex = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);

               // Create the picture
               Picture picture = drawing.createPicture(anchor, pictureIndex);

               // Save changes to the Excel file
               workbook.write(fileOutputStream);
               System.out.println("Chart image added to the Excel file successfully.");

           } catch (IOException e) {
               e.printStackTrace();
           }
	}

	private void saveChartAsImage(JFreeChart barChart, String filePath) {
		try {
            ChartUtilities.saveChartAsPNG(new File(filePath), barChart, 800, 600);
            System.out.println("Chart saved as an image successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}

	/*private static List<String[]> readCsvFile(String filePath) {
        List<String[]> data = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                data.add(values);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        int val=0;
        while (data.size() > val) {
        	System.out.println("CSV Value:"+data.get(val));
        	val++;
        }
        return data;
    }*/

   
    private void createExcelFile(List<Car> cars, String filePath) {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fileOut = new FileOutputStream(filePath)) {
            Sheet sheet = workbook.createSheet("Cars");

            Row header =sheet.createRow(0);
            header.createCell(0).setCellValue("Car Type");
            header.createCell(1).setCellValue("Year");
            header.createCell(2).setCellValue("Color");
            header.createCell(3).setCellValue("Miles");
            
            int rownum=1;
            for(Car item : cars) {
            	Row row =sheet.createRow(rownum++);
            	Cell cell = row.createCell(0);
            	cell.setCellValue(item.getCartype());
            	cell = row.createCell(1);
            	cell.setCellValue(item.getYear());
            	cell = row.createCell(2);
            	cell.setCellValue(item.getColor());
            	cell = row.createCell(3);
            	cell.setCellValue(item.getMiles());
            }
            
            workbook.write(fileOut);
            fileOut.close();
            System.out.println("cars_data.xlsx written successfully on classpath.");
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    private DefaultCategoryDataset loadDataFromExcel(String filePath) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        System.out.println("FilePath:"+filePath);
        try (FileInputStream fileInputStream = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fileInputStream)) {

           Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet
        	

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                Cell carTypeCell = row.getCell(0); // Assuming car types are in column A

                if (carTypeCell != null) {
                    String carType = carTypeCell.getStringCellValue();
                    dataset.addValue(1, "CarType-Miles", carType);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private void displayChart(JFreeChart chart, String title) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 600));
        frame.add(chartPanel, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
    }
}

