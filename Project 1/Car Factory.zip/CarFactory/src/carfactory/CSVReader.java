package carfactory;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class CSVReader {
    public static void main(String[] args) {
        String csvFile = "cars.csv"; // Path to the CSV file

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            // Read the header line first
            line = br.readLine();
            System.out.println("Reading data from CSV file:");
            System.out.println(line); // Print header line

            // Read and process data lines from CSV
            while ((line = br.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                String cartype = tokenizer.nextToken().trim();
                int year = Integer.parseInt(tokenizer.nextToken().trim());
                String color = tokenizer.nextToken().trim();
                int miles = Integer.parseInt(tokenizer.nextToken().trim());

                // Process the car data 
                System.out.println("Car Type: " + cartype);
                System.out.println("Year: " + year);
                System.out.println("Color: " + color);
                System.out.println("Miles: " + miles);
                System.out.println("-------------");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

